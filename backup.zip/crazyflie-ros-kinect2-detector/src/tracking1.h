
#include <opencv2/opencv.hpp>
#include <list>

#ifndef _TRACKING_H_1
#define _TRACKING_H_1

using namespace cv;
using namespace std;

struct node_group {
	int id;
    list<int> nodes;
};

#define PI 3.14159265

typedef struct {
	float x;
	float y;
	vector<Point> points;
	bool found;
	int angle;
	string shape;
} cf_instance1;

void detect_cfs1(Mat * ir, Mat * th_display, cf_instance1* out);

/* Only for libfreenect2 */
// void get_depth_at_xy(void * data, cf_instance * out);

#endif /*_TRACKING_H_*/
