#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <sensor_msgs/PointCloud2.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

int main(int argc, char** argv)
{
  ros::init(argc, argv, "static_image_publisher");
  ros::NodeHandle n;

  image_transport::ImageTransport it(n);
  image_transport::Publisher pub = it.advertise("/static_image", 1);
  cv::Mat image = cv::imread("/home/wawa/crazyflie_ws/src/crazyflie-ros-kinect2-detector/src/2.png", CV_LOAD_IMAGE_COLOR);
  if(image.empty()){
   printf("open error\n");
   }
  cv::waitKey(30);

  sensor_msgs::ImagePtr msg = cv_bridge::CvImage(std_msgs::Header(), "bgr8", image).toImageMsg();
  ros::Rate loop_rate(5);
  
  while (n.ok())
  {
    pub.publish(msg);
    ros::spinOnce();
    loop_rate.sleep();
  }

  return 0;
}



