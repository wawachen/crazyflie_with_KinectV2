
#include <iostream>
#include <signal.h>

#include <opencv2/opencv.hpp>
#include "tracking1.h"

#include <fstream>

#include <cmath>
#include <list>
#include <stack>
#include <set>

// #define and &&

using namespace cv;
using namespace std;

static int th_lower = 800000; //20000
static int th_upper = 1400000;

//static int th_lower = 0;
//static int th_upper = 200000;


void threashold_ir(Mat * ir, int lower, int upper, Mat* th)
{
	inRange(*ir, Scalar(lower), Scalar(upper), *th);
}

int mydistance(Point2f a, Point2f b) {
	return sqrt(pow(a.x - b.x, 2) + pow(a.y - b.y, 2));
}

void detect_cfs1(Mat * ir, Mat * th_display, cf_instance1* out) {

    /* Zero the struct */
    memset(out, 0, sizeof(cf_instance1));

    Mat th;
    threashold_ir(ir, th_lower, th_upper, &th);

	int dilation_size = 1;
	Mat element = getStructuringElement(MORPH_ELLIPSE,
		Size(dilation_size + 1, dilation_size + 1),
		Point(dilation_size, dilation_size));

	erode(th, th, element);
	dilate(th, th, element);
	//erode(th, th, element);
	th_display->setTo(Scalar(0, 0, 0), th);
	// imshow("TH", th);
    Mat canny_output;
    vector<vector<Point> > contours;
    vector<Vec4i> hierarchy;

	findContours(th, contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE, Point(0, 0));

    // Create "drawable" threashold image

    // cv::putText(*th_display, "Test", cvPoint(30,30),
    // 	cv::FONT_HERSHEY_COMPLEX_SMALL, 0.8, cvScalar(100,10,250), 1, CV_AA);
	std::cout<<"found:" << contours.size()<<std::endl;
	if(contours.size()==1){
			// Create a list of all the contours with center and readious
		vector<vector<Point> > contours_poly( contours.size() );
		vector<Rect> boundRect( contours.size() );
		vector<Point2f>center( contours.size() );
		vector<float>radius( contours.size() );

		char id_txt_buffer [50];
		for( int i = 0; i < contours.size(); i++ )
		{
			//approxPolyDP( Mat(contours[i]), contours_poly[i], 3, true );
			//boundRect[i] = boundingRect( Mat(contours_poly[i]) );
			minEnclosingCircle(contours[i], center[i], radius[i]);
			circle(*th_display, center[i], radius[i], Scalar(255, 0, 255), 1);
		
			sprintf (id_txt_buffer, "%d", i);
			// putText(*th_display, id_txt_buffer, center[i],
			// 	FONT_HERSHEY_COMPLEX_SMALL, 0.8, cvScalar(100,10,250), 1, CV_AA);
		}

		out->x = center[0].x;
		out->y = center[0].y;

	}
	else{
		std::cout<<"not ok, should be only one point"<<std::endl;
	}
	
}
