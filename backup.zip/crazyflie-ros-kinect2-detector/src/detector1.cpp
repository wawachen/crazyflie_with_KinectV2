#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <sensor_msgs/PointCloud2.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "crazyflie_driver/Position.h"
#include <geometry_msgs/PoseStamped.h>
#include "crazyflie_driver/GenericLogData.h"

#include <tf/transform_broadcaster.h>
#include <tf/transform_listener.h>
#include <math.h>
#include "tracking1.h"
#include <algorithm>
#include <string> 
#include <numeric>
#include <std_msgs/Int32.h>
#include "shape_detection.h"

static int th_lower = 13000; //20000
static int th_upper = 400000;

int agent_num = 2;
int detect_x  = -1;
int detect_y = -1;
int color_pubsignal = 0;

vector<cf_instance1> cf_g(agent_num);

double z_r = 0;
cv::Mat image_HSV;

ros::Publisher imageThPublisher;
vector<ros::Publisher> posPublisher(4);
ros::Publisher detPublisher;

float SMALL_SIZE = 3.9;

std::vector<int> sort_indexes(const std::vector<float> &v) {
  std::vector<int> idx(v.size());
  std::iota(idx.begin(), idx.end(), 0);
  std::sort(idx.begin(), idx.end(), [&v](int i1, int i2) { return v[i1] < v[i2]; });
  return idx;
}

void threashold_ir(Mat * ir, int lower, int upper, Mat* th)
{
	inRange(*ir, Scalar(lower), Scalar(upper), *th);
}

int mydistance(Point2f a, Point2f b) {
	return sqrt(pow(a.x - b.x, 2) + pow(a.y - b.y, 2));
}

void detect_cfs1(Mat * ir, Mat * th_display) {
  /* Zero the struct */
  for(int i=0; i<agent_num;i++){
    memset(&cf_g[i], 0, sizeof(cf_instance1));  
  }

  Mat th;
  threashold_ir(ir, th_lower, th_upper, &th);

	int dilation_size = 1;
	Mat element = getStructuringElement(MORPH_ELLIPSE,
		Size(dilation_size + 1, dilation_size + 1),
		Point(dilation_size, dilation_size));

	erode(th, th, element);
	dilate(th, th, element);
	//erode(th, th, element);
	th_display->setTo(Scalar(0, 0, 0), th);
	// imshow("TH", th);
  Mat canny_output;
  vector<vector<Point> > contours;
  vector<Vec4i> hierarchy;

	findContours(th, contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE, Point(0, 0));

  vector<int> tips_list(agent_num);
  vector<int> base_list(agent_num);

	std::cout<<"found:" << contours.size()<<std::endl;

	if(contours.size()==(agent_num*2)){
			// Create a list of all the contours with center and readious
		// vector<vector<Point> > contours_poly( contours.size() );
		// vector<Rect> boundRect( contours.size() );
    std_msgs::Int32 num_msg;
    num_msg.data = contours.size()/2;
    detPublisher.publish(num_msg);

		vector<Point2f>center( contours.size() );
		vector<float>radius( contours.size() );

    //approxPolyDP( Mat(contours[i]), contours_poly[i], 3, true );
    //boundRect[i] = boundingRect( Mat(contours_poly[i]) );
    for(int i = 0; i < contours.size(); i++){
      minEnclosingCircle(contours[i], center[i], radius[i]);
      std::cout<<"radius"<<i<<":"<<radius[i];
    }

    //rank them, remove all tips, then rank for lables
    vector<int> rank_radius = sort_indexes(radius);
    std::cout<<"sort"<<rank_radius[0]<<"/"<<rank_radius[1]<<std::endl;
    for(int i = 0; i< contours.size()/2;i++){
      tips_list[i] = rank_radius[i];
      base_list[i] = rank_radius[i+contours.size()/2];
    } 

    vector<float> distance(tips_list.size());

    ShapeDetector sd;
    vector<Point> c;

    for(int i =0; i< base_list.size();i++){
      for(int j=0; j<tips_list.size();j++){
        distance[j] = sqrt(pow(abs(center[base_list[i]].x - center[tips_list[j]].x), 2) + pow(abs(center[base_list[i]].y - center[tips_list[j]].y), 2));
      }
      auto smallest = std::min_element(distance.begin(), distance.end());
      int min_d = std::distance(std::begin(distance), smallest);

      int tip_node = tips_list[min_d];
      std::cout<<"tip is:"<<tip_node;
     
      cf_g[i].x = center[base_list[i]].x;
		  cf_g[i].y = center[base_list[i]].y;
      cf_g[i].points = contours[base_list[i]];
      cf_g[i].found = 1;
      cf_g[i].angle = (int(atan2(center[base_list[i]].y-center[tip_node].y, center[base_list[i]].x-center[tip_node].x)*180/PI)+45+360)%360;
      circle(*th_display, center[base_list[i]], radius[base_list[i]], Scalar(255, 0, 255), 1);
      std::cout<<"base:"<<base_list[i]<<"tip:"<<tip_node<<std::endl;
      line(*th_display, center[base_list[i]], center[tip_node], Scalar(0, 0, 0), 2);

      c = contours[base_list[i]];
      sd.detect(Mat(c));
      string shape = sd.get_shape_type();
      cf_g[i].shape = shape;
    }
	}
	else{
		std::cout<<"not ok, should match agent number"<<std::endl;
    for(int i=0; i<agent_num;i++){
      cf_g[i].found = 0;  
    }
    std_msgs::Int32 num_msg;
    num_msg.data = 0;
    detPublisher.publish(num_msg);
	}
	
}

static void publishTf(float x, float y, float z, int angle, string shape)
{
  static tf::TransformBroadcaster br;
  tf::Transform transform;
  transform.setOrigin( tf::Vector3(x, y, z) );
  tf::Quaternion q;
  q.setRPY(3.14, 0.0, (angle/180)*M_PI);
  transform.setRotation(q);
  
  string pub_name = "/crazyflie/base_link_"+shape;
  br.sendTransform(tf::StampedTransform(transform, ros::Time::now(), "kinect2_ir_optical_frame", pub_name));
}


void publishPose(float x, float y, float z, int angle, string shape)
{ 
  crazyflie_driver::Position pos_msg;
  pos_msg.header.frame_id = "world";

  //we'll just use the most recent transform available for our simple example
  pos_msg.header.stamp = ros::Time();

  pos_msg.x = y;
  pos_msg.y = x;
  pos_msg.z = 1.73-z;

  
  int yw = 0;
  if((angle>=0) && (angle<=90)){
    yw = 90-angle;
  }
  if((angle>90) && (angle<=360)){
    yw = 450-angle;
  }
  pos_msg.yaw = (float(yw)/180)*M_PI;
  // std::cout<<"wawa:"<<yw<<std::endl;

  ROS_INFO("Crazyflie %s published at : %f %f %f %f", shape, pos_msg.x, pos_msg.y, pos_msg.z, pos_msg.yaw);

  // 0 : circle,  1: rectangle, 2: triangle, 3: pentagon
  if(shape == "circle"){
    posPublisher[0].publish(pos_msg);
    std::cout<<"circle"<<std::endl;
  }
  if(shape == "rectangle"){
    posPublisher[1].publish(pos_msg);
    std::cout<<"rectangle"<<std::endl;
  }
  if(shape == "triangle"){
    posPublisher[2].publish(pos_msg);
    std::cout<<"triangle"<<std::endl;
  }
  if(shape == "pentagon"){
    posPublisher[3].publish(pos_msg);
    std::cout<<"pentagon"<<std::endl;
  }

}

void imageCb(const sensor_msgs::ImageConstPtr& msg)
{
  cv_bridge::CvImagePtr cv_ptr;
  try
  {
    cv_ptr = cv_bridge::toCvCopy(msg, "16UC1");
  }
  catch (cv_bridge::Exception& e)
  {
    ROS_ERROR("cv_bridge exception: %s", e.what());
    return;
  }

  cv::Mat ir_image = cv_ptr->image;
  cv::Mat th_display(ir_image.size(), CV_8UC3, cv::Scalar(255, 255, 255));

  cv::namedWindow("TH");
  
  detect_cfs1(&ir_image, &th_display);
  // std::cout<<"wawa"<<std::endl;

  cv_bridge::CvImage cv_image;
  cv_image.image = th_display;
  cv_image.encoding = "rgb8";
  imageThPublisher.publish(cv_image.toImageMsg());

  //real weight  146cm ---> 424 pixel  146/424 = 0.344
  // if(cf1.found){
  //   publishTf((cf1.x-256)*(0.344+0.036)*0.01, (cf1.y-212)*(0.344)*0.01, z_r, yaw);
  //   // publishPose(cf1.x-256, cf1.y-212, z_r, yaw);

  //   ROS_INFO("Crazyflie detected at : %f %f %f %f", cf1.x-256, cf1.y-212, z_r, yaw*57.296);
  // }

}

void rangeCb(const crazyflie_driver::GenericLogDataConstPtr& msg)
{
  float z_1;
  z_1 = msg->values[0]/1000;
}

//get z position 
void pointsCb(const sensor_msgs::PointCloud2ConstPtr& msg)
{
  // because some point cloud value cannot be detected, thus we average the peanut to get height
  float sum = 0;
  int nan_num = 0;

  // if(cf1.found){
  //   for(int i=0;i<cf1.points.size();i++){
  //   float pos_mid_x = (cf1.points[i].x+cf1.x)/2;
  //   float pos_mid_y = (cf1.points[i].y+cf1.y)/2;

  //   int pos = (((int)pos_mid_x)*msg->point_step) + (((int)pos_mid_y)*msg->row_step);
  //   float z = *((float*)&msg->data[pos + msg->fields[2].offset]);

  //   if(isnan(z)){
  //     nan_num = nan_num + 1;
  //     z = 0.0;
  //   }

  //   sum = sum + z;
  //   }

  //   z_r = sum/(cf1.points.size()-nan_num);

  //   ROS_INFO("Crazyflie detected height at : %f ", z_r);
  // }

  for(int i=0;i<agent_num;i++){
    int pos = (((int)cf_g[i].x)*msg->point_step) + (((int)cf_g[i].y)*msg->row_step);
    float z = *((float*)&msg->data[pos + msg->fields[2].offset]);
    // z_r = z;

    float x = *((float*)&msg->data[pos + msg->fields[0].offset]);
    float y = *((float*)&msg->data[pos + msg->fields[1].offset]);

    if(cf_g[i].found==1){
      ROS_INFO("Crazyflie %d detected at : %f %f %f %d", i, x, y, z, cf_g[i].angle);
      //obtain a sequence of points of contour, pointed by the variable 'contour'
      publishPose(x,y,z,cf_g[i].angle,cf_g[i].shape);
      publishTf(x, y, z, cf_g[i].angle,cf_g[i].shape);
    }

  }
  // ROS_INFO("Crazyflie detected at : %f %f %f %f", x, y, z_r, yaw*57.296);
  
}


int main(int argc, char** argv)
{
  ros::init(argc, argv, "detector1");
  ros::NodeHandle n;

  ros::Subscriber imageSub = n.subscribe("/kinect2/sd/image_ir", 1, imageCb);
  ros::Subscriber rangeSub = n.subscribe("/crazyflie/z_range", 1, rangeCb);
  ros::Subscriber pointSub = n.subscribe("/kinect2/sd/points", 1, pointsCb);

  vector<string> shape_collections = {"circle","rectangle","triangle","pentagon"};
  // 0 : circle,  1: rectangle, 2: triangle, 3: pentagon

  imageThPublisher = n.advertise<sensor_msgs::Image>("/detector/threshold", 1);
  for(int i=0;i<4;i++){
    string pname = "/crazyflie/drone_pose_"+shape_collections[i];
    posPublisher[i] = n.advertise<crazyflie_driver::Position>(pname, 1); 
  }
  detPublisher = n.advertise<std_msgs::Int32>("/detector/found_num", 1);

  ros::spin();
  return 0;
}
