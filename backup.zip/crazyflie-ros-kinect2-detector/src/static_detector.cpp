#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <sensor_msgs/PointCloud2.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <geometry_msgs/PoseStamped.h>

#include <tf/transform_broadcaster.h>
#include "tracking.h"
#include "crazyflie_driver/Position.h"
#include <std_msgs/Int32.h>
#include <math.h>
#include <tf/transform_listener.h>

static const std::string OPENCV_WINDOW = "Image window";

ros::Publisher imagePublisher;
ros::Publisher posPublisher_g;
ros::Publisher posPublisher_o;
ros::Publisher detPublisher;
int agent_num = 2;
float pos_o_x;
float pos_o_y;
float pos_g_x;
float pos_g_y;
int angle_g;
int angle_o;
int real_detect_num;

void image_callback(const sensor_msgs::ImageConstPtr& msg)
{
    cv_bridge::CvImagePtr cv_ptr;
    try
    {
        cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::RGB8);
    }
    catch (cv_bridge::Exception& e)
    {
        ROS_ERROR("cv_bridge exception: %s", e.what());
        return;
    }

    cv::Mat image = cv_ptr->image;
    cv::Mat image_HSV;
    cv::Mat threshold_im_green;
    cv::Mat threshold_im_orange;

    cv::Mat canny_output;
    // cv::Mat th_display(image.size(), CV_8UC3, cv::Scalar(255, 255, 255));

    // cv::imshow(OPENCV_WINDOW, image);
    // Convert from BGR to HSV colorspace
    cvtColor(image, image_HSV, COLOR_RGB2HSV);
    // cv::imshow(OPENCV_WINDOW, image);

    cv::inRange(image_HSV, Scalar(70, 63,50), Scalar(99,255,255), threshold_im_green);
    cv::inRange(image_HSV, Scalar(26, 83, 46), Scalar(34, 255, 255), threshold_im_orange);

    //green Scalar(35,43,46), Scalar(77,255,255)
    // Update GUI Window
    // cv::imshow(OPENCV_WINDOW, threshold_im_orange);
    // // cv::imshow(OPENCV_WINDOW, threshold_im_green);
    // cv::waitKey(3);

    int dilation_size = 1.0;
	Mat element = getStructuringElement(MORPH_ELLIPSE,
		Size(dilation_size + 1, dilation_size + 1),
		Point(dilation_size, dilation_size));

    erode(threshold_im_green, threshold_im_green, element);
	dilate(threshold_im_green, threshold_im_green, element);

    erode(threshold_im_orange, threshold_im_orange, element);
	dilate(threshold_im_orange, threshold_im_orange, element);

    // th_display.setTo(Scalar(0, 0, 0), threshold_im);

    // cv::imshow(OPENCV_WINDOW, th_display);
    vector<vector<Point> >  contours_g;
    vector<Vec4i> hierarchy_g;

    vector<vector<Point> >  contours_o;
    vector<Vec4i> hierarchy_o;


    // cv::Size threshold_imType = threshold_im.size();
    // std::cout<<"Type = "<<threshold_imType<<std::endl;
    // cv::imshow(OPENCV_WINDOW, threshold_im_pink);

	findContours(threshold_im_green, contours_g, hierarchy_g, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE, Point(0, 0));
    findContours(threshold_im_orange, contours_o, hierarchy_o, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE, Point(0, 0));

    std::cout<<"green_size"<<contours_g.size()<<std::endl;
    std::cout<<"orange_size"<<contours_o.size()<<std::endl;

    // Create a list of all the contours with center and readious
    vector<Point2f> center_g(2);
    vector<float> radius_g(2);

    vector<Point2f> center_o(2);
    vector<float> radius_o(2);

    char id_txt_buffer [50];
    // ROS_INFO("size:");

    // approxPolyDP(contours[i], contours_poly[i], 3, true);
    // boundRect[i] = boundingRect(contours_poly[i]);

    if(contours_g.size()==2){
        for(int i=0;i<2;i++){
            minEnclosingCircle(contours_g[i], center_g[i], radius_g[i]);
            // std::cout<< "green centre point:"<<center_g<<std::endl;
            // circle(image, center_g[i], 38, Scalar(0, 255, 0), 2.5);
        }
    }else{
        std::cout<<"must have 2 green agent!!"<<std::endl;
    }

    if(contours_o.size()==2){
        for(int i=0;i<2;i++){
            minEnclosingCircle(contours_o[i], center_o[i], radius_o[i]);
            std::cout<< "orange radius:"<<radius_o[i]<<std::endl;
            // circle(image, center_o[i], 38, Scalar(255, 0, 0), 2.5);
        }
    }else{
        std::cout<<"must have 2 orange agent!!"<<std::endl;
    }

    int base_o,tip_o, base_g,tip_g;
    float yaw_gg,yaw_oo;
    std_msgs::Int32 num_msg;

    if((contours_o.size()==2)&&(contours_g.size()==2)){
        real_detect_num = 2;
        num_msg.data = 2;
        detPublisher.publish(num_msg);

        if(radius_g[0]>radius_g[1]){
        base_g = 0;
        tip_g = 1;
        }else{
        base_g = 1;
        tip_g = 0;
        }

        circle(image, center_g[base_g], 38, Scalar(0, 255, 0), 2.5);
        circle(image, center_g[tip_g], 18, Scalar(0, 255, 0), 2.5);

        int yaw_g = (int(atan2(center_g[base_g].y-center_g[tip_g].y, center_g[base_g].x-center_g[tip_g].x)*180/PI)+45+360)%360;

        angle_g = yaw_g; 

        if(radius_o[0]>radius_o[1]){
            base_o = 0;
            tip_o = 1;
        }else{
            base_o = 1;
            tip_o = 0;
        }

        circle(image, center_o[base_o], 38, Scalar(255, 0, 0), 2.5);
        circle(image, center_o[tip_o], 18, Scalar(255, 0, 0), 2.5);

        int yaw_o = (int(atan2(center_o[base_o].y-center_o[tip_o].y, center_o[base_o].x-center_o[tip_o].x)*180/PI)+45+360)%360; 

        angle_o = yaw_o;
    
        // cv::imshow(OPENCV_WINDOW, threshold_im);
        pos_o_x = center_o[base_o].x;
        pos_o_y = center_o[base_o].y;
        pos_g_x = center_g[base_g].x;
        pos_g_y = center_g[base_g].y;

        cv_bridge::CvImage cv_image;
        cv_image.image = image;
        cv_image.encoding = "rgb8";

        imagePublisher.publish(cv_image.toImageMsg());
    }else{
        std::cout<<"must have meet all requirements!!"<<std::endl;
        real_detect_num = 0;
        num_msg.data = 0;
        detPublisher.publish(num_msg);
    }
    
}

static void publishTf(float x, float y, float z, int angle, string color)
{
  static tf::TransformBroadcaster br;
  tf::Transform transform;
  transform.setOrigin( tf::Vector3(x, y, z) );
  tf::Quaternion q;
//   std::cout<<"angle: "<< (float(angle)/180)*M_PI;
  q.setRPY(3.14, 0.0, (float(angle)/180)*M_PI);
  transform.setRotation(q);
  
  string pub_name = "/crazyflie/base_link_"+color;
  br.sendTransform(tf::StampedTransform(transform, ros::Time::now(), "kinect2_rgb_optical_frame", pub_name));
}

void publishPose(float x, float y, float z, int angle, string color)
{
  tf::TransformListener listener; 
  tf::StampedTransform transform;

  geometry_msgs::PoseStamped k_msg;

  k_msg.header.frame_id = "kinect2_rgb_optical_frame";

  //we'll just use the most recent transform available for our simple example
  k_msg.header.stamp = ros::Time();

  //just an arbitrary point in space
  k_msg.pose.position.x = x;
  k_msg.pose.position.y = y;
  k_msg.pose.position.z = z;

  tf::Quaternion q;
  q.setRPY(0, 0, (float(angle)/180)*M_PI);

  k_msg.pose.orientation.x = q[0];
  k_msg.pose.orientation.y = q[1];
  k_msg.pose.orientation.z = q[2];
  k_msg.pose.orientation.w = q[3];

  geometry_msgs::PoseStamped world_msg;
  try{
    ros::Time now = ros::Time::now();
    listener.waitForTransform("kinect2_rgb_optical_frame", "world",
                              now, ros::Duration(0.3));
    listener.transformPose("world", k_msg, world_msg);
  }
  catch(tf::TransformException& ex){
    ROS_ERROR("Received an exception trying to transform a point from \"kinect_camera\" to \"world\": %s", ex.what());
  }

  crazyflie_driver::Position pos_msg;

  pos_msg.x = world_msg.pose.position.x;
  pos_msg.y = world_msg.pose.position.y;
  pos_msg.z = world_msg.pose.position.z;

  tf::Quaternion q1(
        world_msg.pose.orientation.x,
        world_msg.pose.orientation.y,
        world_msg.pose.orientation.z,
        world_msg.pose.orientation.w);

  tf::Matrix3x3 m(q1);
  double roll, pitch, yaw;
  m.getRPY(roll, pitch, yaw);
  pos_msg.yaw = yaw;

  if(color=="green"){
    posPublisher_g.publish(pos_msg);
  }
  if(color=="orange"){
    posPublisher_o.publish(pos_msg);
  }

}

void publishPose1(float x, float y, float z, int angle, string color)
{ 
  geometry_msgs::PoseStamped pos_msg;
  pos_msg.header.frame_id = "world";

  //we'll just use the most recent transform available for our simple example
  pos_msg.header.stamp = ros::Time();

  pos_msg.pose.position.x = y;
  pos_msg.pose.position.y = x;
  pos_msg.pose.position.z = 1.73-z;

  int yw = 0;
  if((angle>=0) && (angle<=90)){
    yw = 90-angle;
  }
  if((angle>90) && (angle<=360)){
    yw = 450-angle;
  }
  
  tf::Quaternion q;
  q.setRPY(0, 0, (float(yw)/180)*M_PI);

  pos_msg.pose.orientation.x = q[0];
  pos_msg.pose.orientation.y = q[1];
  pos_msg.pose.orientation.z = q[2];
  pos_msg.pose.orientation.w = q[3];
  // std::cout<<"wawa:"<<yw<<std::endl;

  if(color=="green"){
    posPublisher_g.publish(pos_msg);
  }
  if(color=="orange"){
    posPublisher_o.publish(pos_msg);
  }

}

void pointsCb(const sensor_msgs::PointCloud2ConstPtr& msg)
{
    if(real_detect_num==2){

        int pos_o = (((int)pos_o_x)*msg->point_step) + (((int)pos_o_y)*msg->row_step);
        float z_o = *((float*)&msg->data[pos_o + msg->fields[2].offset]);
        float x_o = *((float*)&msg->data[pos_o + msg->fields[0].offset]);
        float y_o = *((float*)&msg->data[pos_o + msg->fields[1].offset]);

        int pos_g = (((int)pos_g_x)*msg->point_step) + (((int)pos_g_y)*msg->row_step);
        float z_g = *((float*)&msg->data[pos_g + msg->fields[2].offset]);
        float x_g = *((float*)&msg->data[pos_g + msg->fields[0].offset]);
        float y_g = *((float*)&msg->data[pos_g + msg->fields[1].offset]);

        ROS_INFO("Crazyflie orange detected at : %f %f %f %d", x_o, y_o, z_o,angle_o);
        ROS_INFO("Crazyflie green detected at : %f %f %f %d", x_g, y_g, z_g,angle_g);

        publishTf(x_o, y_o, z_o, angle_o,"orange");
        publishTf(x_g, y_g, z_g, angle_g,"green");

        //qhd
        publishPose1(x_o, y_o, z_o, angle_o,"orange");
        publishPose1(x_g, y_g, z_g, angle_g,"green");

        // ROS_INFO("Crazyflie detected at : %f %f %f %f", x, y, z_r, yaw*57.296);
    }else{
        ROS_INFO("cannot publish crazyflie");
    }
  
}

int main(int argc, char** argv)
{
  ros::init(argc, argv, "static_detector");
  ros::NodeHandle n;

  ros::Subscriber ImageSub = n.subscribe("kinect2/qhd/image_color", 1, image_callback);///kinect2/hd/image_color///static_image /kinect2/sd/image_color_rect
  ros::Subscriber pointSub = n.subscribe("/kinect2/qhd/points", 1, pointsCb);

  posPublisher_o = n.advertise<geometry_msgs::PoseStamped>("/crazyflie/drone_pose_orange", 1);
  posPublisher_g = n.advertise<geometry_msgs::PoseStamped>("/crazyflie/drone_pose_green", 1);
  
  imagePublisher = n.advertise<sensor_msgs::Image>("/detected_image", 1);
  detPublisher = n.advertise<std_msgs::Int32>("/detector/found_num", 1);

  ros::spin();
  return 0;
}

